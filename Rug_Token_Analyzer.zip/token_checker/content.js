// Listen for messages from the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Message received in content script:', request);

    if (request.action === 'getTokenData') {
        console.log('Getting token data for address:', request.tokenAddress);
        const tokenData = extractTokenData(request.tokenAddress);
        console.log('Extracted token data:', tokenData);
        sendResponse({ tokenData });
    }
    return true; // Required to use sendResponse asynchronously
});

function extractTokenData(tokenAddress) {
    try {
        console.log('Starting token data extraction');

        // Log the current URL to verify we're on bullx.io
        console.log('Current URL:', window.location.href);

        // Extract token information from bullx.io page
        const tokenName = findTokenName();
        console.log('Found token name:', tokenName);

        const ticker = findTicker();
        console.log('Found ticker:', ticker);

        const ca = findContractAddress() || tokenAddress;
        console.log('Found contract address:', ca);

        const xLink = findXLink();
        console.log('Found X link:', xLink);

        const data = {
            tokenName,
            ticker,
            ca,
            xLink
        };

        console.log('Final token data:', data);
        return data;
    } catch (error) {
        console.error('Error extracting token data:', error);
        return null;
    }
}

function findTokenName() {
    const possibleSelectors = [
        'h1[class*="token"]',
        'h1[class*="name"]',
        '.token-name',
        '.token-title',
        '.token-header h1',
        'h1.name',
        '.token-details h1',
        // Add more selectors based on actual page structure
    ];

    return findFirstMatchingElement(possibleSelectors);
}

function findTicker() {
    const possibleSelectors = [
        '[class*="ticker"]',
        '[class*="symbol"]',
        '.token-symbol',
        '.token-ticker',
        '.ticker-symbol',
        // Add more selectors based on actual page structure
    ];

    return findFirstMatchingElement(possibleSelectors);
}

function findContractAddress() {
    const possibleSelectors = [
        '[class*="contract"]',
        '[class*="address"]',
        '.token-address',
        '.contract-address',
        '.token-contract',
        // Look for elements containing a Solana-style address
        '[class*="address"]:matches(/[1-9A-HJ-NP-Za-km-z]{32,44}/)',
        // Add more selectors based on actual page structure
    ];

    return findFirstMatchingElement(possibleSelectors);
}

function findXLink() {
    // First try to find a direct link to Twitter/X
    const socialLinks = Array.from(document.querySelectorAll('a'));
    const xLink = socialLinks.find(a => {
        const href = (a.href || '').toLowerCase();
        return href.includes('twitter.com') || href.includes('x.com');
    });

    if (xLink) {
        return xLink.href;
    }

    // If no direct link found, try looking for social icons or buttons
    const possibleSelectors = [
        'a[href*="twitter.com"]',
        'a[href*="x.com"]',
        '[class*="twitter"] a',
        '[class*="social"] a[href*="twitter.com"]',
        '[class*="social"] a[href*="x.com"]',
        // Add more selectors based on actual page structure
    ];

    const element = document.querySelector(possibleSelectors.join(','));
    return element?.href || null;
}

function findFirstMatchingElement(selectors) {
    for (const selector of selectors) {
        try {
            const elements = document.querySelectorAll(selector);
            for (const element of elements) {
                const text = element.textContent.trim();
                if (text && text !== '') {
                    console.log(`Found match for selector "${selector}":`, text);
                    return text;
                }
            }
        } catch (e) {
            console.warn(`Error with selector "${selector}":`, e);
        }
    }
    return null;
}

// Log when the content script is loaded
console.log('Rug Radar content script loaded on:', window.location.href);

// Add this to help with debugging
console.log('Rug Radar content script loaded');
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM Content Loaded - Testing selectors...');
    const testData = extractTokenData();
    console.log('Test Data:', testData);
}); 