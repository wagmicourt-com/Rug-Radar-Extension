chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'navigate') {
        chrome.tabs.update({ url: request.url });
    }
}); 