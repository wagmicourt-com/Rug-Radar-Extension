document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('enterRadar').addEventListener('click', () => {
        window.location.href = 'popup.html';
    });
}); 