document.addEventListener('DOMContentLoaded', () => {
    const backButton = document.querySelector('.back-button');
    const scanButton = document.getElementById('scanButton');
    const tokenInput = document.getElementById('tokenInput');

    // Handle back button
    backButton.addEventListener('click', () => {
        window.location.href = 'index.html';
    });

    // Handle scan button click
    if (scanButton) {
        scanButton.addEventListener('click', () => {
            const tokenAddress = tokenInput.value.trim();
            if (!tokenAddress) {
                showError('Please enter a token address');
                return;
            }

            // Show loading state
            showLoading();

            // Request token data from the content script
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (!tabs || !tabs[0] || !tabs[0].id) {
                    showError('Could not access current tab');
                    return;
                }

                chrome.tabs.sendMessage(tabs[0].id, { 
                    action: 'getTokenData',
                    tokenAddress: tokenAddress 
                }, (response) => {
                    // Check for any chrome runtime errors
                    if (chrome.runtime.lastError) {
                        console.error('Chrome runtime error:', chrome.runtime.lastError);
                        showError('Error communicating with the page. Please make sure you are on bullx.io');
                        return;
                    }

                    if (response && response.tokenData) {
                        updateUI(response.tokenData);
                    } else {
                        showError('Could not retrieve token information. Please try again.');
                    }
                });
            });
        });
    }

    // Handle Enter key in input field
    if (tokenInput) {
        tokenInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter' && scanButton) {
                scanButton.click();
            }
        });
    }

    const tryAgainButton = document.getElementById('tryAgainButton');
    if (tryAgainButton) {
        tryAgainButton.addEventListener('click', function() {
            // Show loading overlay and prevent interaction
            const overlay = document.getElementById('loadingOverlay');
            if (overlay) {
                overlay.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }
        });
    }
});

function showLoading() {
    const scanButton = document.getElementById('scanButton');
    if (scanButton) {
        scanButton.disabled = true;
        scanButton.textContent = 'Loading...';
    }
    
    document.querySelectorAll('.info-value').forEach(el => {
        if (el.tagName.toLowerCase() === 'a') {
            el.textContent = 'Loading...';
        } else {
            el.textContent = 'Loading...';
        }
    });
}

function showError(message) {
    const infoSection = document.querySelector('.info-section');
    if (infoSection) {
        infoSection.innerHTML = `<div class="error-message">${message}</div>`;
    }
    
    const scanButton = document.getElementById('scanButton');
    if (scanButton) {
        scanButton.disabled = false;
        scanButton.textContent = 'Scan Now';
    }
}

function updateUI(tokenData) {
    // Reset the scan button
    const scanButton = document.getElementById('scanButton');
    if (scanButton) {
        scanButton.disabled = false;
        scanButton.textContent = 'Scan Now';
    }

    // Update each field if the element exists
    const elements = {
        tokenName: document.getElementById('tokenName'),
        ticker: document.getElementById('ticker'),
        ca: document.getElementById('ca'),
        xLink: document.getElementById('xLink')
    };

    if (elements.tokenName) elements.tokenName.textContent = tokenData.tokenName || 'N/A';
    if (elements.ticker) elements.ticker.textContent = tokenData.ticker || 'N/A';
    if (elements.ca) elements.ca.textContent = tokenData.ca || 'N/A';
    
    if (elements.xLink) {
        if (tokenData.xLink) {
            elements.xLink.textContent = 'View on X';
            elements.xLink.href = tokenData.xLink;
        } else {
            elements.xLink.textContent = 'N/A';
            elements.xLink.removeAttribute('href');
        }
    }

    console.log('UI updated with token data:', tokenData);
} 